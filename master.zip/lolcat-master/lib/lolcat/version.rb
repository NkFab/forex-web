module Lolcat
  VERSION = "99.9.11"
end
